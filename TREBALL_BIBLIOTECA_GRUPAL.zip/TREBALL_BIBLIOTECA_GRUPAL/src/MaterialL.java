public abstract class MaterialL {

	private String id;
	private String titulo;
	private String autor;
	private String tematica;

	public MaterialL(String id, String titulo, String autor, String tematica) {
		this.id = id;
		this.titulo = titulo;
		this.autor = autor;
		this.tematica = tematica;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getTematica() {
		return tematica;
	}

	public void setTematica(String tematica) {
		this.tematica = tematica;
	}
}
//Fet per Iman Issidri, Joel Espinosa i Iolanda Martínez.