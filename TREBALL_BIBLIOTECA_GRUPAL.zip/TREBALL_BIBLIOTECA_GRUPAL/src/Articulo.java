public class Articulo extends MaterialL {

	private boolean disponible;

	public Articulo(String id, String titulo, String autor, String tematica, boolean disponible) {
		super(id, titulo, autor, tematica);
		this.disponible = disponible;
	}

	public boolean isDisponible() {
		return disponible;
	}

	public void setDisponible(boolean disponible) {
		this.disponible = disponible;
	}

	public void verificarDisponibilidad() {
		if (disponible) {
			System.out.println("El artículo está disponible.");
		} else {
			System.out.println("El artículo no está disponible. Contactar al autor: " + getAutor());
		}
	}
}
//Fet per Iman Issidri, Joel Espinosa i Iolanda Martínez.