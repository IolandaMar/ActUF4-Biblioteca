public class Libro extends MaterialL {

	private boolean reservado;

	public Libro(String id, String titulo, String autor, String tematica, boolean reservado) {
		super(id, titulo, autor, tematica);
		this.reservado = reservado;
	}

	public boolean isReservado() {
		return reservado;
	}

	public void setReservado(boolean reservado) {
		this.reservado = reservado;
	}

	public void reservar() {
		if (!reservado) {
			reservado = true;
			System.out.println("Libro reservado con éxito.");
		} else {
			System.out.println("El libro ya está reservado.");
		}
	}

	public void cancelarReserva() {
		if (reservado) {
			reservado = false;
			System.out.println("Reserva cancelada con éxito.");
		} else {
			System.out.println("El libro no estaba reservado.");
		}
	}
}
//Fet per Iman Issidri, Joel Espinosa i Iolanda Martínez.