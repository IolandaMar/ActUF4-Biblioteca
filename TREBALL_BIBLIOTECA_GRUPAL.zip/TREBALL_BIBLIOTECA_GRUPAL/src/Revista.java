public class Revista extends MaterialL {

	private double precio;

	public Revista(String id, String titulo, String autor, String tematica, double precio) {
		super(id, titulo, autor, tematica);
		this.precio = precio;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public double calcularPrecioCompra(int cantidad) {
		return precio * cantidad;
	}
}
//Fet per Iman Issidri, Joel Espinosa i Iolanda Martínez.