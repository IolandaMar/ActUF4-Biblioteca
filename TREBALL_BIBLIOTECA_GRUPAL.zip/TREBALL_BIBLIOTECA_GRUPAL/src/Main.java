import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		boolean salir = false;

		while (!salir) {
			System.out.println("---- Biblioteca ----");
			System.out.println("1. Mostrar información del libro");
			System.out.println("2. Mostrar información de la revista");
			System.out.println("3. Mostrar información del artículo");
			System.out.println("4. Salir");
			System.out.print("Seleccione una opción: ");

			int opcion = scanner.nextInt();
			scanner.nextLine(); // Consumir el salto de línea

			switch (opcion) {
			case 1:
				mostrarInformacionLibro();
				break;
			case 2:
				mostrarInformacionRevista();
				break;
			case 3:
				mostrarInformacionArticulo();
				break;
			case 4:
				salir = true;
				System.out.println("Saliendo del programa...");
				break;
			default:
				System.out.println("Opción inválida. Por favor, seleccione una opción válida.");
				break;
			}
		}
		scanner.close();
	}

	public static void mostrarInformacionLibro() {
		Libro libro = new Libro("001", "El Quijote", "Miguel de Cervantes", "Novela", false);
		System.out.println("Información del libro:");
		System.out.println("Título: " + libro.getTitulo());
		System.out.println("Autor: " + libro.getAutor());
		System.out.println("Tema: " + libro.getTematica());
		libro.reservar();
		libro.reservar(); // Intentar reservar de nuevo
		System.out.println();
	}

	public static void mostrarInformacionRevista() {
		Revista revista = new Revista("002", "National Geographic", "Varios autores", "Divulgación científica", 3.5);
		System.out.println("Información de la revista:");
		System.out.println("Título: " + revista.getTitulo());
		System.out.println("Autor: " + revista.getAutor());
		System.out.println("Tema: " + revista.getTematica());
		System.out.println("Precio por unidad: $" + revista.getPrecio());
		System.out.println("Precio por 5 unidades: $" + revista.calcularPrecioCompra(5));
		System.out.println();
	}

	public static void mostrarInformacionArticulo() {
		Articulo articulo = new Articulo("003", "El futuro de la inteligencia artificial", "John Doe", "Tecnología",
				true);
		System.out.println("Información del artículo:");
		System.out.println("Título: " + articulo.getTitulo());
		System.out.println("Autor: " + articulo.getAutor());
		System.out.println("Tema: " + articulo.getTematica());
		articulo.verificarDisponibilidad();
		System.out.println();
	}
}
//Fet per Iman Issidri, Joel Espinosa i Iolanda Martínez.